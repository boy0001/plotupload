<?php
    header('Location: http://13.13.13.13');
    exit();
?>